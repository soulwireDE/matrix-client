import { useEffect, useState } from 'react'
import * as sdk from 'matrix-js-sdk'
import useAppStore from './store/useAppStore'
import { loadSession, clearSession } from './store/sessionStore'
import { initNotifications } from './services/notifications.backup'
import { attachNotificationListener } from './services/matrixNotifications'
import LoginScreen from './components/LoginScreen'
import MainLayout from './components/layout/MainLayout'
import initCryptoWasm from "@matrix-org/matrix-sdk-crypto-wasm";

export default function App() {
  const { isLoggedIn, setLoggedIn, setMatrixClient, setCurrentUser } = useAppStore()
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    async function tryRestoreSession() {
      try {
        const session = await loadSession();

        if (session?.accessToken && session?.userId && session?.baseUrl) {

          // 🔐 Crypto-WASM initialisieren
          await initCryptoWasm();

          // 🔐 Client mit Crypto-Stores erstellen
          const client = sdk.createClient({
            baseUrl: session.baseUrl,
            store: new sdk.IndexedDBStore({
              indexedDB: window.indexedDB,
              dbName: "matrix-store",
            }),
            cryptoStore: new sdk.IndexedDBCryptoStore(
              window.indexedDB,
              "matrix-crypto"
            ),
          });

          // 🔐 Token + Device setzen
          client.setAccessToken(session.accessToken);
          client.deviceId = session.deviceId;
          client.credentials = { userId: session.userId };

          // 🔐 Crypto initialisieren
          await client.initCrypto();

          // Test ob Token gültig ist
          await client.whoami();

          // Zustand setzen
          setMatrixClient(client);
          setCurrentUser({ userId: session.userId });
          setLoggedIn(true);

          // 🔄 Sync starten
          client.startClient({ initialSyncLimit: 20 });

          await initNotifications();
          attachNotificationListener(client);
        }
      } catch (e) {
        console.log("Session ungültig, neu einloggen:", e.message);
        await clearSession();
      } finally {
        setChecking(false);
      }
    }

    tryRestoreSession();
  }, []); // <-- DIESE Klammer hat bei dir gefehlt!

  if (checking) {
    return (
      <div style={{
        height: '100vh', width: '100vw',
        background: 'var(--dc-bg-1)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{ color: 'var(--dc-text-muted)', fontSize: '14px' }}>
          Lade Session…
        </div>
      </div>
    )
  }

  return isLoggedIn ? <MainLayout /> : <LoginScreen />
}
